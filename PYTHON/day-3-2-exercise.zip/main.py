# 🚨 Don't change the code below 👇
height = float(input("enter your height in m: "))
weight = float(input("enter your weight in kg: "))
# 🚨 Don't change the code above 👆
#Write your code below this line 👇
BMI = round(weight/(height**2))
if BMI > 18.5 :
  if BMI < 25 :
   print(f"Tu BMI es {BMI}, tienes un peso normal")
  elif BMI < 30 :
   print(f"Tu BMI es {BMI}, tiene un ligero sobrepeso") 
  elif BMI < 35 :
   print(f"Tu BMI es {BMI}, son obesos")
  else:
    print(f"Tu BMI es {BMI}, son clinicamente obesos")
else:
  print(f"Tu BMI es {BMI}, tiene desnutricion")     

